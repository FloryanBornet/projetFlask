#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Flask, request, render_template, redirect, url_for, abort, flash

app = Flask(__name__)
app.secret_key = 'une cle(token) : grain de sel(any random string)'

categoriesDepenses = [
    {'id':1,'libelleCategorie':'Autoroute'},
    {'id':2,'libelleCategorie':'Carburant'},
    {'id':3,'libelleCategorie':'Repas'},
    {'id':4,'libelleCategorie':'Hebergement'}
]
depenses = [
    {'id':1, 'destinataireDepense':'Service d\'autoroute Vinci','montant':'35','description':'Péages Belfort-Lyon', 'date_depense':'2014-04-20' , 'categorieDepense_id':1, 'image':'img_depense_1.png'},
    {'id':2, 'destinataireDepense':'Organisation ACD','montant':'410.47','description':'Comité de direction', 'date_depense':'2014-07-03' , 'categorieDepense_id':3, 'image':'img_depense_2.png'},
    {'id':3, 'destinataireDepense':'intendance UTBM','montant':'120','description':'forum étudiants', 'date_depense':'2014-08-18',  'categorieDepense_id':4, 'image':'img_depense_4.png'},
    {'id':4, 'destinataireDepense':'Autoroute Ouest','montant':'25.5','description':'Péages Paris-Nantes', 'date_depense':'2014-07-28' , 'categorieDepense_id':1, 'image':'img_depense_3.png'},
    {'id':5, 'destinataireDepense':'TotalEnergies','montant':'45','description':'Sans plomb 95 35L', 'date_depense':'2014-04-14' , 'categorieDepense_id':2, 'image':'img_depense_3.png', 'image':'img_depense_5.png'},
    {'id':6, 'destinataireDepense':'Hilton Hotels & Resorts','montant':'842','description':'Hotel Hilton Paris', 'date_depense':'2014-01-06' , 'categorieDepense_id':4, 'image':'img_depense_6.png'},
    {'id':7, 'destinataireDepense':'Service d\'autoroute Vinci','montant':'42.00','description':'Péages Belfort-Paris', 'date_depense':'2014-12-07' , 'categorieDepense_id':1, 'image':'img_depense_1.png'},
    {'id':8, 'destinataireDepense':'TotalEnergies','montant':'75','description':'Diezel 60L', 'date_depense':'2014-10-31' , 'categorieDepense_id':2, 'image':'img_depense_3.png'}
]

@app.route('/')
def show_accueil():
    return render_template('layout.html')

@app.route('/categorie-depense/show')
def show_categorie_depense():
    print(categoriesDepenses)
    return render_template('categorie_depense/show_categorie_depense.html', categoriesDepenses=categoriesDepenses)

@app.route('/categorie-depense/add', methods=['GET'])
def add_categorie_depense():
    return render_template('categorie_depense/add_categorie_depense.html')

@app.route('/categorie-depense/add', methods=['POST'])
def valid_add_categorie_depense():
    libelleCategorie = request.form.get('libelleCategorie', '')
    print(u'categorie ajoutée, libellé :', libelleCategorie)
    message = u'categorie ajoutée , libelle de la catégorie :'+libelleCategorie
    flash(message, 'alert-success')
    return redirect('/categorie-depense/show')

@app.route('/categorie-depense/delete', methods=['GET'])
def delete_categorie_depense():
    id = request.args.get('id', '')
    print("une catégorie de dépense supprimée, id :",id)
    message=u'une catégorie de dépense supprimée, id : ' + id
    flash(message, 'alert-warning')
    return redirect('/categorie-depense/show')

@app.route('/categorie-depense/edit', methods=['GET'])
def edit_categorie_depense():
    id = request.args.get('id', '')
    libelleCategorie = request.args.get('libelleCategorie', '')
    id=int(id)
    categoriesDepense = categoriesDepenses[id-1]
    return render_template('categorie_depense/edit_categorie_depense.html', categoriesDepense=categoriesDepense)

@app.route('/categorie-depense/edit', methods=['POST'])
def valid_edit_categorie_depense():
    libelleCategorie = request.form['libelleCategorie']
    id = request.form.get('id', '')
    print(u'categorie de dépense modifiée, id: ',id, " libelleCategorie :", libelleCategorie)
    message=u'categorie de dépense modifiée, id: ' + id + " libelleCategorie : " + libelleCategorie
    flash(message, 'alert-success')
    return redirect('/categorie-depense/show')

@app.route('/depense/show')
def show_depense():
    return render_template('depense/show_depense.html', depenses=depenses)

@app.route('/depense/add', methods=['GET'])
def add_depense():
    return render_template('depense/add_depense.html', categoriesDepenses=categoriesDepenses)

@app.route('/depense/add', methods=['POST'])
def valid_add_depense():
    destinataireDepense = request.form.get('destinataireDepense', '')
    categorieDepense_id = request.form.get('categorieDepense_id', '')
    montant = request.form.get('montant', '')
    description = request.form.get('description', '')
    date_depense = request.form.get('date_depense', '')
    image = request.form.get('image', '')
    print(u'Dépense ajoutée , Destinataire de la dépense: ', destinataireDepense, ' - id de la categorie de dépense :', categorieDepense_id, ' - montant:', montant, ' - description:', description, ' - date de la dépense:', date_depense, ' - image:', image)
    message = u'Dépense ajoutée , destinataireDepense:'+destinataireDepense + '- categorieDepense_id :' + categorieDepense_id + ' - montant:' + montant + ' - description:'+  description + ' - date_depense:' + date_depense + ' - image:' + image
    flash(message, 'alert-success')
    return redirect('/depense/show')

@app.route('/depense/delete', methods=['GET'])
def delete_depense():
    id = request.args.get('id', '')
    message=u'une dépense supprimée, id : ' + id
    flash(message, 'alert-warning')
    return redirect('/depense/show')

@app.route('/depense/edit', methods=['GET'])
def edit_depense():
    id = request.args.get('id', '')
    id = int(id)
    depense = depenses[id-1]
    return render_template('depense/edit_depense.html', depense=depense, categoriesDepenses=categoriesDepenses)

@app.route('/depense/edit', methods=['POST'])
def valid_edit_depense():
    id = request.form.get('id', '')
    destinataireDepense = request.form.get('destinataireDepense', '')
    libelleCategorie = request.form.get('libelleCategorie')
    montant = request.form.get('montant', '')
    description = request.form.get('description', '')
    date_depense = request.form.get('date_depense', '')
    image = request.form.get('image', '')
    print(u'dépense modifiée , destinataireDepense : ', destinataireDepense, ' - categorieDepense_id :', libelleCategorie, ' - montant:', montant, ' - description:', description, ' - date_depense:', date_depense, ' - image:', image)
    message = u'dépense modifiée , destinataireDepense:'+destinataireDepense + '- categorieDepense_id :' + libelleCategorie + ' - montant:' + montant + ' - description:' + description + ' - date_depense:' + date_depense + ' - image:' + image
    flash(message, 'alert-success')
    return redirect('/depense/show')

@app.route('/depense/filtre', methods=['GET'])
def filtre_depense():
    filter_word = request.args.get('filter_word', None)
    filter_value_min = request.args.get('filter_value_min', None)
    filter_value_max = request.args.get('filter_value_max', None)
    filter_items = request.args.getlist('filter_items', None)
    if filter_word and filter_word != "":
        message = u'filtre sur le mot : ' + filter_word
        flash(message, 'alert-success')
    if filter_value_min or filter_value_max:
        min = str(filter_value_min).replace(' ', '').replace(',', '.')
        max = str(filter_value_max).replace(' ', '').replace(',', '.')
        if min.replace('.', '', 1).isdigit() and max.replace('.', '', 1).isdigit():
            if float(min) < float(max):
                message = u'filtre sur la colonne avec un numérique entre : ' + min + " et " + max
                flash(message, 'alert-success')
            else:
                message = u'min < max'
                flash(message, 'alert-warning')
        else:
            message = u'min ' + min + ' et max ' + max + ' doivent être des numériques positifs'
            flash(message, 'alert-warning')
    if filter_items and filter_items !=[]:
        message = u'case à cocher selectionnée : '
        for case in filter_items:
            message +=' id: ' + case + ' '
        flash(message, 'alert-success')
    return render_template('depense/front_depense_filtre_show.html', depenses=depenses, categoriesDepenses=categoriesDepenses)

if __name__ == '__main__':
    app.run()